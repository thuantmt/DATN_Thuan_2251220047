# Hướng dẫn sử dụng bộ chấm IELTS Academic Writing Task 1

## 1. Mục đích

Folder này chứa bộ prompt và schema cho quy trình đánh giá bài IELTS Academic Writing Task 1 theo hai giai đoạn:

- **Stage 1 - AI Examiner:** chấm bốn tiêu chí IELTS và đưa ra band điểm.
- **Stage 2 - Diagnostic:** phân tích nguyên nhân lỗi và đề xuất cách cải thiện, không chấm lại band.

Chỉ sử dụng các file trong folder `Task 1` cho bài viết Task 1. Không trộn prompt hoặc schema với folder `Task 2`.

## 2. Các file

| File | Chức năng |
| --- | --- |
| `PROMPT_STAGE1_AI_EXAMINER.md` | System prompt cho examiner Stage 1 |
| `schema-stage1-examiner.json` | Schema kiểm tra JSON đầu ra Stage 1 |
| `PROMPT_STAGE2_DIAGNOSTIC.md` | System prompt cho diagnostic engine Stage 2 |
| `schema-stage2-diagnostic.json` | Schema kiểm tra JSON đầu ra Stage 2 |

## 3. Quy trình xử lý

### Bước 1: Chạy Stage 1

Gửi cho model ba đầu vào:

1. **Task question:** đề bài đầy đủ.
2. **Visual:** biểu đồ, bảng, quy trình, bản đồ hoặc hình minh họa. Nếu không có visual, ghi rõ là không có.
3. **Candidate response:** toàn bộ bài viết của thí sinh.

Model phải trả về **chỉ một JSON object**, không có Markdown, lời chào hoặc phần giải thích bên ngoài JSON.

Stage 1 phải đánh giá độc lập:

- Task Achievement (TA);
- Coherence and Cohesion (CC);
- Lexical Resource (LR);
- Grammatical Range and Accuracy (GRA).

Đối với bài có visual, visual là nguồn sự thật duy nhất để kiểm tra số liệu, xu hướng, so sánh, đơn vị, ngày tháng và các giai đoạn. Không được tự suy đoán số liệu khó đọc.

### Bước 2: Kiểm tra đầu ra Stage 1

Validate JSON bằng `schema-stage1-examiner.json` trước khi chuyển sang Stage 2.

Kiểm tra thêm các điều kiện nghiệp vụ:

- `task` phải là `IELTS_Academic_Writing_Task_1`;
- `minimum_word_requirement` phải là `150`;
- `below_minimum_word_requirement` phải khớp với `word_count`;
- nếu không có visual, `visual_analysis.available` phải là `false` và `visual_type` phải là `null`;
- bốn criterion bands và overall phải nằm trong khoảng IELTS hợp lệ, theo bước `0.5`;
- mọi nhận xét quan trọng phải có evidence tương ứng.

Nếu validation thất bại, sửa hoặc yêu cầu model tạo lại JSON trước khi chạy Stage 2.

### Bước 3: Chạy Stage 2

Gửi cho model bốn đầu vào:

1. Task question;
2. Visual, nếu có;
3. Candidate response;
4. Toàn bộ JSON hợp lệ từ Stage 1.

Stage 2 dùng kết quả Stage 1 làm dữ liệu tham chiếu. Kết quả Stage 2 phải sao chép chính xác các band vào `stage1_reference`; không được tính lại, thay đổi hoặc tạo một overall band mới.

Stage 2 tập trung vào:

- overview và key-feature selection;
- độ chính xác của dữ liệu và xu hướng;
- grouping và progression;
- từ vựng mô tả xu hướng, so sánh và định lượng;
- lỗi ngữ pháp có tính lặp lại;
- sentence-level corrections;
- root causes và kế hoạch cải thiện.

## 4. Quy tắc đánh giá quan trọng

- Không tính band từ số lỗi, số từ nâng cao, số câu phức hoặc số indicator yếu.
- Không hạ band chỉ vì một lỗi đơn lẻ.
- Không tạo số liệu, xu hướng, câu trích dẫn hoặc lỗi không xuất hiện trong dữ liệu đầu vào.
- Overview phải mô tả bức tranh tổng thể; chỉ có từ “Overall” không đủ để được xem là overview tốt.
- Với visual không rõ, dùng confidence thấp và không dùng cách diễn giải đó làm lý do duy nhất để hạ Task Achievement.
- Stage 2 là công cụ chẩn đoán học tập, không phải examiner thứ hai.

## 5. Mẫu đóng gói đầu vào

```text
TASK QUESTION:
[Dán đề bài đầy đủ]

VISUAL:
[Đính kèm visual hoặc ghi: No visual supplied]

CANDIDATE RESPONSE:
[Dán toàn bộ bài viết]
```

Khi chạy Stage 2, thêm:

```text
STAGE 1 EXAMINER RESULT:
[Dán nguyên JSON Stage 1 đã được validate]
```

