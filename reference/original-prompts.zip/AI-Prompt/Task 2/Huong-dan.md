# Hướng dẫn sử dụng bộ chấm IELTS Academic Writing Task 2

## 1. Mục đích

Folder này chứa bộ prompt và schema cho quy trình đánh giá bài IELTS Academic Writing Task 2 theo hai giai đoạn:

- **Stage 1 - AI Examiner:** chấm bốn tiêu chí IELTS và đưa ra band điểm.
- **Stage 2 - Diagnostic:** phân tích điểm mạnh, lỗi lặp lại và hướng học tập, không chấm lại band.

Chỉ sử dụng các file trong folder `Task 2` cho bài luận Task 2. Không dùng schema Task 1 cho bài luận và không dùng prompt Task 1 cho bài có thesis/arguments.

## 2. Các file

| File | Chức năng |
| --- | --- |
| `PROMPT_STAGE1_AI_EXAMINER.md` | System prompt cho examiner Stage 1 |
| `schema-stage1-examiner.json` | Schema kiểm tra JSON đầu ra Stage 1 |
| `PROMPT_STAGE2_DIAGNOSTIC.md` | System prompt cho diagnostic engine Stage 2 |
| `schema-stage2-diagnostic.json` | Schema kiểm tra JSON đầu ra Stage 2 |

## 3. Quy trình xử lý

### Bước 1: Chạy Stage 1

Gửi cho model ba đầu vào:

1. **Task 2 question:** đề bài đầy đủ.
2. **Task context, nếu có:** chỉ cung cấp thông tin đi kèm đề; không bổ sung dữ kiện bên ngoài nếu đề không yêu cầu.
3. **Candidate essay:** toàn bộ bài luận của thí sinh.

Model phải trả về **chỉ một JSON object**, không có Markdown hoặc nội dung bên ngoài JSON.

Stage 1 phải nhận diện question type và các yêu cầu thực tế của đề, sau đó đánh giá độc lập:

- Task Response (TR);
- Coherence and Cohesion (CC);
- Lexical Resource (LR);
- Grammatical Range and Accuracy (GRA).

Không bắt buộc một bố cục cứng như introduction - two body paragraphs - conclusion nếu cấu trúc khác vẫn rõ ràng, logic và đáp ứng đề.

### Bước 2: Kiểm tra đầu ra Stage 1

Validate JSON bằng `schema-stage1-examiner.json`.

Kiểm tra thêm các điều kiện nghiệp vụ:

- `task` phải là `IELTS_Writing_Task_2`;
- `stage` phải là `examiner`;
- `task_analysis.question_requirements` phải được rút ra từ đúng đề bài;
- `requirement_count` phải khớp số requirement thực tế;
- `scores.task_response` phải dùng TR, không dùng TA;
- bốn criterion bands và overall phải nằm trong khoảng IELTS hợp lệ, theo bước `0.5`;
- mỗi criterion phải có evidence cụ thể từ bài viết.

Nếu validation thất bại, sửa hoặc yêu cầu model tạo lại JSON trước khi chạy Stage 2.

### Bước 3: Chạy Stage 2

Gửi cho model bốn đầu vào:

1. Task 2 question;
2. Task context, nếu có;
3. Candidate essay;
4. Toàn bộ JSON hợp lệ từ Stage 1.

Đầu ra Stage 2 phải có:

- `task: IELTS_Writing_Task_2`;
- `stage: diagnostic`;
- `stage1_reference` chứa nguyên vẹn bốn criterion bands và overall từ Stage 1;
- đúng 18 indicator cho mỗi nhóm: `TR01`-`TR18`, `CC01`-`CC18`, `LR01`-`LR18`, `GRA01`-`GRA18`.

Indicator là công cụ chẩn đoán, không phải công thức tính band. Khi một vấn đề không thể quan sát từ bài viết, dùng `not_observable` hoặc `not_applicable`.

Stage 2 tập trung vào:

- mức độ bao phủ các yêu cầu của đề;
- thesis/position và tính nhất quán của quan điểm;
- main ideas, explanation, reasoning và development;
- relevance và specificity của examples;
- paragraph structure và logical progression;
- từ vựng lập luận, collocation và word formation;
- sentence-level corrections, root causes và improvement plan.

## 4. Quy tắc đánh giá quan trọng

- Không tính band từ số lỗi, số indicator yếu, số ví dụ hoặc công thức trọng số.
- Không đánh giá quan điểm dựa trên việc examiner đồng ý hay không đồng ý với ý kiến của thí sinh.
- Không tự thêm luận điểm, dẫn chứng hoặc thông tin thực tế để “cứu” bài viết.
- Một bài có ngôn ngữ tốt vẫn có thể có Task Response thấp nếu bỏ sót yêu cầu quan trọng của đề.
- Không bắt buộc conclusion hoặc kiểu bố cục cụ thể nếu chúng không cần thiết và bài vẫn hoàn chỉnh, mạch lạc.
- Chỉ xem lỗi là recurring pattern khi có đủ bằng chứng; không biến lỗi đơn lẻ thành nguyên nhân hệ thống.
- Stage 2 không được thay đổi band hoặc tạo band thay thế cho Stage 1.

## 5. Mẫu đóng gói đầu vào

```text
TASK 2 QUESTION:
[Dán đề bài đầy đủ]

TASK CONTEXT:
[Dán thông tin được cung cấp cùng đề, hoặc ghi: No additional context]

CANDIDATE ESSAY:
[Dán toàn bộ bài luận]
```

Khi chạy Stage 2, thêm:

```text
STAGE 1 EXAMINER RESULT:
[Dán nguyên JSON Stage 1 đã được validate]
```

